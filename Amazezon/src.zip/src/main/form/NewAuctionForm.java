package main.form;

public class NewAuctionForm {

	private String title;
	private String category;
	private String picture;
	private String description;
	private String postageDetails;
	private String reservePrice;
	private String biddingStartPrice;
	private String biddingIncrement;
	private String endTime;
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPostageDetails() {
		return postageDetails;
	}

	public void setPostageDetails(String postageDetails) {
		this.postageDetails = postageDetails;
	}

	public String getReservePrice() {
		return reservePrice;
	}

	public void setReservePrice(String reservePrice) {
		this.reservePrice = reservePrice;
	}

	public String getBiddingStartPrice() {
		return biddingStartPrice;
	}

	public void setBiddingStartPrice(String biddingStartPrice) {
		this.biddingStartPrice = biddingStartPrice;
	}

	public String getBiddingIncrement() {
		return biddingIncrement;
	}

	public void setBiddingIncrement(String biddingIncrement) {
		this.biddingIncrement = biddingIncrement;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}


}
